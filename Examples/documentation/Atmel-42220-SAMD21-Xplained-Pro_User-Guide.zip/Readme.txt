Filelist:
SAMD21_Xplained_Pro_design_documentation_release_rev2.pdf : Design Documentation
BOM\Bill of Materials Fitted- SAMD21_Xplained_Pro_release_rev2.xls : BOM, all components
ExportSTEP\SAMD21_Xplained_Pro_release_rev2.step : 3D Model of PCBA
Gerber\SAMD21_Xplained_Pro_release_rev2.GP1 : Gerber files for GND
Gerber\SAMD21_Xplained_Pro_release_rev2.GP2 : Gerber files for POWER
Gerber\SAMD21_Xplained_Pro_release_rev2.GM1 : Gerber files for Mechanical 1
Gerber\SAMD21_Xplained_Pro_release_rev2.GBO : Gerber files for Bottom Overlay
Gerber\SAMD21_Xplained_Pro_release_rev2.GBL : Gerber files for Bottom Layer LF-signals
Gerber\SAMD21_Xplained_Pro_release_rev2.GBS : Gerber files for Bottom Solder
Gerber\SAMD21_Xplained_Pro_release_rev2.GBP : Gerber files for Bottom Paste
Gerber\SAMD21_Xplained_Pro_release_rev2.GTL : Gerber files for Top Layer LF-signals
Gerber\SAMD21_Xplained_Pro_release_rev2.GTO : Gerber files for Top Overlay
Gerber\SAMD21_Xplained_Pro_release_rev2.GTP : Gerber files for Top Paste
Gerber\SAMD21_Xplained_Pro_release_rev2.GTS : Gerber files for Top Solder
NC Drill\SAMD21_Xplained_Pro_release_rev2.txt : Drill files, ASCII
NC Drill\SAMD21_Xplained_Pro_release_rev2.drl : Drill files, gerber
NC Drill\SAMD21_Xplained_Pro_release_rev2.drr : Drill files, report
